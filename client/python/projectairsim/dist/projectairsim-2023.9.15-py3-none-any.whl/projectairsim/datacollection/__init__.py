"""
Copyright (C) Microsoft Corporation. All rights reserved.
"""
__version__ = "0.1.0"
__airsim_client_version__ = "0.1.20"
